
<?php $__env->startSection('page_title','Personal | Info'); ?>
<?php $__env->startSection('personal_info_selected','active'); ?>
<?php $__env->startSection('container'); ?>
 <!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
          </div>
          
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title"><b>PERSONAL INFORMATION</b>
                  <a href="<?php echo e(url('user/manage-personal-info')); ?>/<?php echo e(session('USER_ID')); ?>"  class="btn-sm btn btn-primary" style="
                  position: absolute;
                  right: 14px;
                  margin: 0 auto;
                  top: 8px;
              "><i class="fa fa-edit"></i></a>
                </h3>
              </div>
            
              <div class="row">
                <div class="col-12 col-md-6 col-lg-6">
                  <div class="mt-3 ml-3 card-primary card-outline card card-body">
                    <strong class="text-center"> 
                      PROFILE IMAGE</strong>
     
                       <hr>
      
                        <img style="max-height:auto;" width="50%" src="<?php echo e(url('storage/media').'/'.$personal_info[0]->profile_image); ?>" alt="">
                        <hr>
                        <strong>Name</strong>
    
                        <p class="text-muted"><?php echo e($personal_info[0]->name); ?></p>
        
                   </div>
                </div>
                <div class="col-12 col-md-6 col-lg-6">
                  <div class="mt-3 mr-3 card-primary card-outline card card-body">
                    
                  
                    <strong>Email</strong>
    
                    <p class="text-muted"><?php echo e($personal_info[0]->email); ?></p>
    
                    <hr>
                    <strong>Mobile Number</strong>
    
                    <p class="text-muted"><?php echo e($personal_info[0]->phone); ?></p>
    
                    <hr>

    
                    <strong>CITY</strong>
    
                    <p class="text-muted"><?php echo e($personal_info[0]->city); ?></p>
    
                    </div>
                </div>
              </div>
              
              <!-- /.card-body -->
            </div>
          
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\dev-work\my-git\cmw_assignment\resources\views/user/personal_info.blade.php ENDPATH**/ ?>