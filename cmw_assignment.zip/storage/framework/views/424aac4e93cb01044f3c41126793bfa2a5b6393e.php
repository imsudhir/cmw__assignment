
<?php $__env->startSection('page_title','User | Update Contact info'); ?>
<?php $__env->startSection('update_personal_info_selected','active'); ?>

<?php $__env->startSection('container'); ?>
 <!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
          <div class="row">
          <div class="col-12">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title"><b>MANAGE CONTACT INFORMATION.</b></h3>
               <a href="<?php echo e(url('user/personal-info')); ?>" class="btn-sm btn-primary" style="float: right; position: absolute;right: 14px;margin: 0 auto;top: 8px;">  <i class="fa fa-arrow-left"  aria-hidden="true"></i></a>

              </div>
              <!-- /.card-header -->
              <form action="<?php echo e(route('user.manage_personal_info_process')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="form-group">
                          <label for="name">Name*</label>
                          <input type="text" name="name" disabled class="form-control" id="name" value="<?php echo e($update_personal_info[0]->name); ?>"
                           placeholder="name" />
                           
                        </div>
                    </div>
                    <div class="col-xl-6">
                        <div class="form-group">
                        <label for="p_address">Mobile number*</label>
                        <input type="text" name="phone" class="form-control" id="p_cphoneity" value="<?php echo e($update_personal_info[0]->phone); ?>"  placeholder="mobile number">
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger" role="alert">
                            <?php echo e($message); ?>

                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                   
                    <div class="col-xl-6">
                      <div class="form-group">
                        <label for="city">City*</label>
                        <input type="text" name="city" class="form-control" id="city" value="<?php echo e($update_personal_info[0]->city); ?>" placeholder="City">
                        <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger" role="alert">
                            <?php echo e($message); ?>

                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                    
                </div>
                     
                    <div class="col-xl-4">
                        <div class="form-group">
                          <input type="hidden" name="update_user_id" value="<?php echo e(session('USER_ID')); ?>">
                            <button class="btn btn-primary" type="submit" >SAVE</button>
                       
                        </div>
              </div>
            </form>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\dev-work\my-git\cmw_assignment\resources\views/user/manage_personal_info.blade.php ENDPATH**/ ?>